"use client"

import CleaningServiceForm from "../components/cleaning-service-form"

export default function Page() {
  return (
    <main>
      <CleaningServiceForm />
    </main>
  )
}
