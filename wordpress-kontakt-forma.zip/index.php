<?php
// Silence is golden
?>
